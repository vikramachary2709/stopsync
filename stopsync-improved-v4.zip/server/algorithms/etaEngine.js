function haversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c; // kilometers
}

function calculateETA(bus, stop, routePolylines = []) {
  if (!bus || !stop) return { etaMinutes: null, source: 'unknown' };

  // Calculate straight-line or polyline distance
  const distKm = haversineDistance(bus.latitude, bus.longitude, stop.latitude, stop.longitude);
  const speedKmh = bus.speed > 5 ? bus.speed : 25; // default urban transit speed 25 km/h if stationary

  // Basic ETA calculation in minutes
  let rawEta = Math.round((distKm / speedKmh) * 60);

  // Apply recency decay weight if live pings exist
  let isLive = false;
  if (bus.lastPingTime) {
    const ageSeconds = (Date.now() - new Date(bus.lastPingTime).getTime()) / 1000;
    if (ageSeconds < 300) { // Fresh ping within 5 mins
      isLive = true;
    }
  }

  return {
    etaMinutes: Math.max(1, rawEta),
    distanceKm: parseFloat(distKm.toFixed(2)),
    source: isLive ? 'Live Crowd Ping' : 'Scheduled Timetable',
    isLive: isLive
  };
}

module.exports = { haversineDistance, calculateETA };
