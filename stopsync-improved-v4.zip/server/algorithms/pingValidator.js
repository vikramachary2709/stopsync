const { haversineDistance } = require('./etaEngine');

function validatePingCorridor(pingLat, pingLon, routeStops, maxDistanceMeters = 200) {
  if (!routeStops || routeStops.length === 0) return { valid: false, reason: 'No route stops available' };

  let minDistanceMeters = Infinity;
  for (const stop of routeStops) {
    const distMeters = haversineDistance(pingLat, pingLon, stop.latitude, stop.longitude) * 1000;
    if (distMeters < minDistanceMeters) {
      minDistanceMeters = distMeters;
    }
  }

  const isValid = minDistanceMeters <= maxDistanceMeters;
  return {
    valid: isValid,
    distanceToCorridorMeters: Math.round(minDistanceMeters),
    reason: isValid ? 'Within 200m corridor threshold' : `Ping rejected: ${Math.round(minDistanceMeters)}m is outside 200m route radius`
  };
}

module.exports = { validatePingCorridor };
