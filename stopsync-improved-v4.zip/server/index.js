const express = require('express');
const cors = require('cors');
const logger = require('./middleware/logger');
const errorHandler = require('./middleware/errorHandler');
const { verifyToken, generateToken } = require('./middleware/authMiddleware');
const { pingRateLimiter } = require('./middleware/rateLimiter');
const { calculateETA } = require('./algorithms/etaEngine');
const { validatePingCorridor } = require('./algorithms/pingValidator');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Request logging middleware
app.use((req, res, next) => {
  logger.info(`[HTTP ${req.method}] ${req.url}`);
  next();
});

// Mock database store
const mockData = {
  routes: [
    { routeId: '500D', name: 'Outer Ring Road Express', origin: 'Silk Board', destination: 'Hebbal', stopsCount: 12 },
    { routeId: '335E', name: 'IT Corridor Shuttle', origin: 'Majestic', destination: 'Kadugodi', stopsCount: 14 }
  ],
  stops: [
    { stopId: 'ST-101', name: 'Tech Park Gate', latitude: 12.9716, longitude: 77.5946, routeId: '500D' },
    { stopId: 'ST-102', name: 'ORR Junction', latitude: 12.9800, longitude: 77.6000, routeId: '500D' }
  ],
  buses: [
    { busId: 'BUS-12', routeId: '500D', latitude: 12.9700, longitude: 77.5920, speed: 28, occupancy: 'Moderate Crowding', lastPingTime: new Date().toISOString() }
  ]
};

// Authentication endpoint
app.post('/api/auth/login', (req, res) => {
  const { username } = req.body;
  const user = { userId: 'USR-' + Math.floor(Math.random() * 900 + 100), username: username || 'Commuter' };
  const token = generateToken(user);
  logger.info(`[Auth] User ${user.username} logged in successfully.`);
  res.json({ success: true, user, token, karmaPoints: 10 });
});

// Routes endpoint
app.get('/api/routes', (req, res) => {
  res.json({ success: true, routes: mockData.routes });
});

// Next-bus ETA endpoint
app.get('/api/eta/:stopId', (req, res) => {
  const stop = mockData.stops.find(s => s.stopId === req.params.stopId) || mockData.stops[0];
  const bus = mockData.buses[0];
  const eta = calculateETA(bus, stop);
  res.json({ success: true, stop, bus, eta });
});

// Authenticated & Rate-Limited Location Ping endpoint
app.post('/api/pings', verifyToken, pingRateLimiter, (req, res, next) => {
  try {
    const { latitude, longitude, occupancy } = req.body;
    
    // Validate ping corridor (200m)
    const validation = validatePingCorridor(latitude, longitude, mockData.stops, 200);
    if (!validation.valid) {
      logger.warn(`[Ping Rejected] ${validation.reason}`);
      return res.status(400).json({ success: false, error: validation.reason });
    }

    // Update bus state
    mockData.buses[0].latitude = latitude;
    mockData.buses[0].longitude = longitude;
    if (occupancy) mockData.buses[0].occupancy = occupancy;
    mockData.buses[0].lastPingTime = new Date().toISOString();

    logger.info(`[Ping Success] User ${req.user.username} submitted ping at (${latitude}, ${longitude})`);
    res.json({
      success: true,
      message: 'Location broadcasted successfully! +10 Transit Karma awarded.',
      karmaAwarded: 10,
      validation
    });
  } catch (err) {
    next(err);
  }
});

// Global Error Handler
app.use(errorHandler);

app.listen(PORT, () => {
  logger.info(`StopSync Server running on port ${PORT}`);
});

module.exports = app;
