const rateLimit = require('express-rate-limit');

const pingRateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute window
  max: 10, // Limit each IP to 10 location pings per minute to prevent spamming
  message: {
    success: false,
    error: 'Rate limit exceeded: Too many location pings submitted. Please wait a minute.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

module.exports = { pingRateLimiter };
