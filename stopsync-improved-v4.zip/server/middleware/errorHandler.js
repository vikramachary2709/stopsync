const logger = require('./logger');

function errorHandler(err, req, res, next) {
  logger.error(`[Error Handler] ${err.stack || err.message}`);
  
  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    success: false,
    error: err.message || 'Internal Server Error',
    timestamp: new Date().toISOString()
  });
}

module.exports = errorHandler;
