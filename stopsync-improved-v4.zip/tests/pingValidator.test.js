const { validatePingCorridor } = require('../server/algorithms/pingValidator');

describe('StopSync Algorithmic Unit Tests - 200m Polyline Ping Validator', () => {
  const mockStops = [
    { latitude: 12.9716, longitude: 77.5946 },
    { latitude: 12.9800, longitude: 77.6000 }
  ];

  test('accepts pings within 200 meters of predefined route stops', () => {
    const validPing = { latitude: 12.9718, longitude: 77.5948 }; // ~30 meters away
    const result = validatePingCorridor(validPing.latitude, validPing.longitude, mockStops, 200);

    expect(result.valid).toBe(true);
    expect(result.distanceToCorridorMeters).toBeLessThanOrEqual(200);
  });

  test('rejects malicious or out-of-corridor pings (> 200m away)', () => {
    const invalidPing = { latitude: 13.0500, longitude: 77.7000 }; // ~10km away
    const result = validatePingCorridor(invalidPing.latitude, invalidPing.longitude, mockStops, 200);

    expect(result.valid).toBe(false);
    expect(result.reason).toContain('rejected');
  });
});
