const request = require('supertest');
const express = require('express');
const { generateToken } = require('../server/middleware/authMiddleware');

const app = express();
app.use(express.json());

// Mock API endpoint for testing
app.post('/api/auth/login', (req, res) => {
  const token = generateToken({ id: 101, username: 'commuter1' });
  res.json({ success: true, token, karmaPoints: 50 });
});

app.get('/api/routes', (req, res) => {
  res.json({ success: true, routes: [{ routeId: '500D', name: 'Outer Ring Road' }] });
});

describe('StopSync API Integration Test Suite', () => {
  test('GET /api/routes returns route directory', async () => {
    const res = await request(app).get('/api/routes');
    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.routes.length).toBeGreaterThan(0);
  });

  test('POST /api/auth/login returns valid JWT token', async () => {
    const res = await request(app).post('/api/auth/login').send({ username: 'commuter1' });
    expect(res.statusCode).toBe(200);
    expect(res.body.token).toBeDefined();
    expect(res.body.karmaPoints).toBe(50);
  });
});
