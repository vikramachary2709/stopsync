const { haversineDistance, calculateETA } = require('../server/algorithms/etaEngine');

describe('StopSync Algorithmic Unit Tests - ETA Engine', () => {
  test('haversineDistance calculates accurate km between Tech Park and ORR Junction', () => {
    const techPark = { latitude: 12.9716, longitude: 77.5946 };
    const orrJunction = { latitude: 12.9800, longitude: 77.6000 };
    
    const distance = haversineDistance(techPark.latitude, techPark.longitude, orrJunction.latitude, orrJunction.longitude);
    expect(distance).toBeGreaterThan(0.5);
    expect(distance).toBeLessThan(2.0);
  });

  test('calculateETA returns Live Crowd Ping for fresh ping (<5 mins old)', () => {
    const bus = { latitude: 12.9716, longitude: 77.5946, speed: 30, lastPingTime: new Date().toISOString() };
    const stop = { latitude: 12.9800, longitude: 77.6000 };

    const result = calculateETA(bus, stop);
    expect(result.source).toBe('Live Crowd Ping');
    expect(result.isLive).toBe(true);
    expect(result.etaMinutes).toBeGreaterThanOrEqual(1);
  });

  test('calculateETA falls back to Scheduled Timetable for old/missing pings', () => {
    const tenMinutesAgo = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    const bus = { latitude: 12.9716, longitude: 77.5946, speed: 25, lastPingTime: tenMinutesAgo };
    const stop = { latitude: 12.9800, longitude: 77.6000 };

    const result = calculateETA(bus, stop);
    expect(result.source).toBe('Scheduled Timetable');
    expect(result.isLive).toBe(false);
  });
});
