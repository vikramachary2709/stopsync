const request = require('supertest');
const app = require('../server/index');

describe('REST API Core Endpoints', () => {
  test('GET /api/routes returns route array', async () => {
    const res = await request(app).get('/api/routes');
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test('POST /api/pings records a valid passenger location ping', async () => {
    const res = await request(app)
      .post('/api/pings')
      .set('x-user-id', 'tester_01')
      .send({
        routeId: '500D',
        busId: 'BUS_101',
        lat: 12.9172,
        lng: 77.6228,
        occupancy: 'Seats Available'
      });
    
    expect(res.statusCode).toBe(201);
    expect(res.body.karmaAwarded).toBe(10);
  });
});
