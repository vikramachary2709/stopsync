const request = require('supertest');
const app = require('../server/index');

describe('Saved Routes API Endpoints (SQLite Persistent Store)', () => {
  test('POST /api/saved-routes saves a route bookmark for user', async () => {
    const res = await request(app)
      .post('/api/saved-routes')
      .set('x-user-id', 'test_user_101')
      .send({ routeId: '500D' });
    
    expect(res.statusCode).toBe(201);
    expect(res.body.message).toContain('saved successfully');
  });

  test('GET /api/saved-routes retrieves persistent saved routes', async () => {
    const res = await request(app)
      .get('/api/saved-routes')
      .set('x-user-id', 'test_user_101');
    
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test('DELETE /api/saved-routes/:routeId removes a saved route bookmark', async () => {
    const res = await request(app)
      .delete('/api/saved-routes/500D')
      .set('x-user-id', 'test_user_101');
    
    expect(res.statusCode).toBe(200);
    expect(res.body.message).toContain('removed');
  });
});
