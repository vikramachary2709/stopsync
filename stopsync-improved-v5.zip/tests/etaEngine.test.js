const { haversineDistance, calculateETA } = require('../server/algorithms/etaEngine');

describe('ETA Engine & Haversine Distance Heuristics', () => {
  test('calculates correct haversine distance between known coordinates', () => {
    // Silk Board to HSR Layout (~1.8 km)
    const dist = haversineDistance(12.9172, 77.6228, 12.9116, 77.6389);
    expect(dist).toBeGreaterThan(1.0);
    expect(dist).toBeLessThan(2.5);
  });

  test('calculates accurate ETA in minutes based on distance and speed', () => {
    const eta = calculateETA(12.9172, 77.6228, 12.9279, 77.6692, 30, 0);
    expect(eta.etaMinutes).toBeGreaterThan(0);
    expect(eta.confidence).toBe(100);
  });

  test('applies recency time decay penalty for older pings', () => {
    const freshEta = calculateETA(12.9172, 77.6228, 12.9279, 77.6692, 30, 0);
    const staleEta = calculateETA(12.9172, 77.6228, 12.9279, 77.6692, 30, 15);
    expect(staleEta.confidence).toBeLessThan(freshEta.confidence);
  });
});
