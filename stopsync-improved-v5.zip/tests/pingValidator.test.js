const { isWithinCorridor } = require('../server/algorithms/pingValidator');

describe('Corridor Location Ping Validation', () => {
  const routeStops = [
    { name: 'Silk Board', lat: 12.9172, lng: 77.6228 },
    { name: 'HSR Layout', lat: 12.9116, lng: 77.6389 }
  ];

  test('accepts ping within corridor distance', () => {
    const validPing = isWithinCorridor(12.9173, 77.6229, routeStops, 200);
    expect(validPing).toBe(true);
  });

  test('rejects ping far outside corridor distance', () => {
    const invalidPing = isWithinCorridor(13.0827, 80.2707, routeStops, 200);
    expect(invalidPing).toBe(false);
  });
});
