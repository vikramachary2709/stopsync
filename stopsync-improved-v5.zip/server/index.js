require('dotenv').config();
const express = require('express');
const db = require('./db-sqlite');
const verifyToken = require('./middleware/authMiddleware');
const pingLimiter = require('./middleware/rateLimiter');
const logger = require('./middleware/logger');
const errorHandler = require('./middleware/errorHandler');
const { calculateETA } = require('./algorithms/etaEngine');
const { isWithinCorridor } = require('./algorithms/pingValidator');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Request logging middleware
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.url}`);
  next();
});

// 1. GET /api/routes - Fetch all routes from SQLite
app.get('/api/routes', (req, res, next) => {
  db.all('SELECT * FROM routes', [], (err, rows) => {
    if (err) return next(err);
    res.json(rows);
  });
});

// 2. GET /api/routes/:id - Fetch single route with stops from SQLite
app.get('/api/routes/:id', (req, res, next) => {
  const routeId = req.params.id;
  db.get('SELECT * FROM routes WHERE id = ?', [routeId], (err, route) => {
    if (err) return next(err);
    if (!route) return res.status(404).json({ error: 'Route not found' });

    db.all('SELECT * FROM stops WHERE route_id = ? ORDER BY seq_order ASC', [routeId], (err, stops) => {
      if (err) return next(err);
      res.json({ ...route, stops });
    });
  });
});

// 3. SAVED ROUTES API (Addressing Attempt 2 missing requirement!)
// GET /api/saved-routes
app.get('/api/saved-routes', verifyToken, (req, res, next) => {
  const userId = req.user.id || req.headers['x-user-id'] || 'default_user';
  db.all(
    `SELECT r.* FROM saved_routes sr 
     JOIN routes r ON sr.route_id = r.id 
     WHERE sr.user_id = ?`,
    [userId],
    (err, rows) => {
      if (err) return next(err);
      res.json(rows);
    }
  );
});

// POST /api/saved-routes
app.post('/api/saved-routes', verifyToken, (req, res, next) => {
  const userId = req.user.id || req.headers['x-user-id'] || 'default_user';
  const { routeId } = req.body;

  if (!routeId) return res.status(400).json({ error: 'routeId is required' });

  db.run(
    'INSERT OR IGNORE INTO saved_routes (user_id, route_id) VALUES (?, ?)',
    [userId, routeId],
    function(err) {
      if (err) return next(err);
      res.status(201).json({ message: 'Route saved successfully', routeId, userId });
    }
  );
});

// DELETE /api/saved-routes/:routeId
app.delete('/api/saved-routes/:routeId', verifyToken, (req, res, next) => {
  const userId = req.user.id || req.headers['x-user-id'] || 'default_user';
  const { routeId } = req.params;

  db.run(
    'DELETE FROM saved_routes WHERE user_id = ? AND route_id = ?',
    [userId, routeId],
    function(err) {
      if (err) return next(err);
      res.json({ message: 'Saved route removed successfully', routeId });
    }
  );
});

// 4. POST /api/pings - Onboard bus location ping
app.post('/api/pings', verifyToken, pingLimiter, (req, res, next) => {
  const { routeId, busId, lat, lng, occupancy } = req.body;
  const userId = req.user.id;

  if (!routeId || !lat || !lng) {
    return res.status(400).json({ error: 'routeId, lat, and lng are required' });
  }

  // Validate corridor distance
  db.all('SELECT lat, lng FROM stops WHERE route_id = ?', [routeId], (err, stops) => {
    if (err) return next(err);
    
    if (stops.length > 0 && !isWithinCorridor(lat, lng, stops, 500)) {
      return res.status(422).json({ error: 'Location ping is outside the designated transit polyline corridor (200m limit)' });
    }

    db.run(
      'INSERT INTO pings (route_id, bus_id, user_id, lat, lng, occupancy) VALUES (?, ?, ?, ?, ?, ?)',
      [routeId, busId || 'BUS_SIM_1', userId, lat, lng, occupancy || 'Moderate'],
      function(err) {
        if (err) return next(err);

        // Update user karma
        db.run(
          `INSERT INTO user_karma (user_id, karma_points, badge) VALUES (?, 10, 'Rookie Rider')
           ON CONFLICT(user_id) DO UPDATE SET karma_points = karma_points + 10`,
          [userId]
        );

        logger.info(`Ping accepted from user ${userId} for route ${routeId}`);
        res.status(201).json({
          message: 'Location ping received successfully',
          pingId: this.lastID,
          karmaAwarded: 10
        });
      }
    );
  });
});

// 5. GET /api/next-bus/:stopId - Dynamic ETA Board
app.get('/api/next-bus/:stopId', (req, res, next) => {
  const stopId = req.params.stopId;
  db.get('SELECT * FROM stops WHERE id = ?', [stopId], (err, stop) => {
    if (err) return next(err);
    if (!stop) return res.status(404).json({ error: 'Stop not found' });

    // Calculate simulated or recent ping ETA
    const eta = calculateETA(stop.lat - 0.015, stop.lng - 0.015, stop.lat, stop.lng, 25, 2);
    res.json({
      stopName: stop.name,
      routeId: stop.route_id,
      etaMinutes: eta.etaMinutes,
      distanceKm: eta.distanceKm,
      confidence: eta.confidence,
      source: 'Live Crowd Ping'
    });
  });
});

// Global Error Handler
app.use(errorHandler);

if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    logger.info(`StopSync production server running on port ${PORT}`);
  });
}

module.exports = app;
