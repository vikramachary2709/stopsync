const rateLimit = require('express-rate-limit');

const pingLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10, // max 10 location pings per minute
  message: { error: 'Too many location pings sent. Please wait a minute before broadcasting again.' },
  standardHeaders: true,
  legacyHeaders: false
});

module.exports = pingLimiter;
