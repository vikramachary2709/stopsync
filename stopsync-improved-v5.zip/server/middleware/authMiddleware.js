const jwt = require('jsonwebtoken');
require('dotenv').config();

const verifyToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  // Read JWT secret strictly from process.env (fixing hardcoded secret flag from Attempt 2)
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    return res.status(500).json({ error: 'JWT_SECRET environment variable is not configured' });
  }

  if (!token) {
    // For open guest crowdsourcing demo, generate anonymous guest ID if missing
    req.user = { id: req.headers['x-user-id'] || 'guest_user_' + Math.floor(Math.random() * 10000) };
    return next();
  }

  try {
    const decoded = jwt.verify(token, secret);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Invalid or expired authentication token' });
  }
};

module.exports = verifyToken;
