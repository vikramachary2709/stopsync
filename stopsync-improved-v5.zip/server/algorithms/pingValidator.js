const { haversineDistance } = require('./etaEngine');

function isWithinCorridor(pingLat, pingLng, routeStops, maxDistanceMeters = 200) {
  if (!routeStops || routeStops.length === 0) return false;
  
  for (let stop of routeStops) {
    const distMeters = haversineDistance(pingLat, pingLng, stop.lat, stop.lng) * 1000;
    if (distMeters <= maxDistanceMeters) {
      return true;
    }
  }
  return false;
}

module.exports = { isWithinCorridor };
