function haversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

function calculateETA(busLat, busLng, stopLat, stopLng, avgSpeedKmh = 25, pingAgeMins = 0) {
  const distKm = haversineDistance(busLat, busLng, stopLat, stopLng);
  let rawEtaMins = (distKm / avgSpeedKmh) * 60;
  
  // Exponential recency decay penalty
  const decayWeight = Math.exp(-0.05 * pingAgeMins);
  const adjustedEta = Math.round(rawEtaMins / Math.max(decayWeight, 0.2));
  
  return {
    etaMinutes: Math.max(1, adjustedEta),
    distanceKm: parseFloat(distKm.toFixed(2)),
    confidence: parseFloat((decayWeight * 100).toFixed(0))
  };
}

module.exports = { haversineDistance, calculateETA };
