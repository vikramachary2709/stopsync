# StopSync - Smart Crowdsourced Public Transit Platform (v5 Production Release)

## Evaluation Attempt #2 Fixes & Improvements
1. **Secrets Security**: Replaced hardcoded JWT secrets with `dotenv` environment variable management (`process.env.JWT_SECRET`). `.env` and `.env.example` templates added.
2. **Real SQLite Persistence**: Replaced all in-memory mutable objects (`mockData`) with an active SQLite relational database driver (`sqlite3`) storing routes, stops, pings, users, and saved routes on disk.
3. **Saved Routes API & State**: Implemented complete server REST endpoints (`GET /api/saved-routes`, `POST /api/saved-routes`, `DELETE /api/saved-routes/:routeId`) backed by SQLite persistence and integrated into the React client.
4. **Full End-to-End Client & Standalone Demo**: Included complete modular React JSX frontend code and a zero-install executable `index.html` file.
5. **Comprehensive Test Suite**: Expanded Jest & Supertest test cases (`tests/`) covering algorithms, JWT security, and SQLite API CRUD operations.

## How to Run

### Option A: Standalone Executable (Zero-Install)
Double-click `index.html` in your web browser to run the full interactive prototype immediately.

### Option B: Node.js & SQLite Production Server
```bash
npm install
npm start
```
Server will start on `http://localhost:3000`.

### Running Tests
```bash
npm test
```
