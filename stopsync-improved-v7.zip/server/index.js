require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');
const swaggerUi = require('swagger-ui-express');

const db = require('./db-sqlite');
const authMiddleware = require('./middleware/authMiddleware');
const { validatePingInput } = require('./middleware/inputValidator');
const { pingLimiter } = require('./middleware/rateLimiter');
const logger = require('./middleware/logger');
const errorHandler = require('./middleware/errorHandler');
const { calculateETA } = require('./algorithms/etaEngine');
const { validatePingProximity } = require('./algorithms/pingValidator');
const openApiDoc = require('./docs/openapi.json');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
});

app.use(cors());
app.use(express.json());

// API Documentation Endpoint
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(openApiDoc));

// Auth Route: Login & JWT Issue
app.post('/api/auth/login', (req, res) => {
  const { username } = req.body;
  const userId = username || `commuter_${Math.floor(Math.random() * 1000)}`;
  const token = jwt.sign({ userId }, process.env.JWT_SECRET || 'StopSync_Production_Secure_JWT_Secret_Key_2026!#90Plus', { expiresIn: '24h' });
  res.json({ token, userId, message: 'Authentication successful.' });
});

// Routes API
app.get('/api/routes', async (req, res, next) => {
  try {
    const routes = await db.allAsync("SELECT * FROM routes");
    res.json(routes);
  } catch (err) {
    next(err);
  }
});

app.get('/api/routes/:id/stops', async (req, res, next) => {
  try {
    const stops = await db.allAsync("SELECT * FROM stops WHERE route_id = ? ORDER BY sequence ASC", [req.params.id]);
    res.json(stops);
  } catch (err) {
    next(err);
  }
});

// Live ETAs Endpoint
app.get('/api/routes/:id/eta', async (req, res, next) => {
  try {
    const routeId = req.params.id;
    const stops = await db.allAsync("SELECT * FROM stops WHERE route_id = ? ORDER BY sequence ASC", [routeId]);
    const latestPing = await db.getAsync("SELECT * FROM pings WHERE route_id = ? ORDER BY timestamp DESC LIMIT 1", [routeId]);

    if (!latestPing || stops.length === 0) {
      return res.json({
        routeId,
        source: 'Scheduled Timetable',
        board: stops.map((s, idx) => ({ stopId: s.id, stopName: s.stop_name, etaMinutes: (idx + 1) * 8, isLive: false }))
      });
    }

    const board = stops.map(stop => {
      const eta = calculateETA(stop.lat, stop.lng, latestPing.lat, latestPing.lng, latestPing.timestamp);
      return {
        stopId: stop.id,
        stopName: stop.stop_name,
        etaMinutes: eta.etaMinutes,
        distanceKm: eta.distanceKm,
        confidenceScore: eta.confidenceScore,
        isLive: eta.isLive,
        occupancy: latestPing.occupancy
      };
    });

    res.json({ routeId, busId: latestPing.bus_id, source: 'Live Crowd Telemetry', board });
  } catch (err) {
    next(err);
  }
});

// Location Ping Submission (STRICT JWT REQUIRED + TRANSACTION SUPPORT)
app.post('/api/pings', authMiddleware, pingLimiter, validatePingInput, async (req, res, next) => {
  const { routeId, busId, lat, lng, occupancy } = req.body;
  const userId = req.user.userId;
  const timestamp = Date.now();

  try {
    const stops = await db.allAsync("SELECT lat, lng FROM stops WHERE route_id = ?", [routeId]);
    const prox = validatePingProximity(lat, lng, stops);

    if (!prox.isValid) {
      return res.status(422).json({
        error: 'Unprocessable Entity',
        message: `Location ping rejected: ${prox.distanceMeters}m from route polyline (Max threshold 200m).`
      });
    }

    // ACID Transaction for Ping + Karma Awarding
    await db.beginTransaction();
    await db.runAsync(
      "INSERT INTO pings (route_id, bus_id, user_id, lat, lng, occupancy, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [routeId, busId, userId, lat, lng, occupancy || 'Moderate Crowding', timestamp]
    );

    // Increment Karma
    let karmaRow = await db.getAsync("SELECT points FROM user_karma WHERE user_id = ?", [userId]);
    let newPoints = (karmaRow ? karmaRow.points : 0) + 10;
    let badge = newPoints >= 100 ? 'Gold Navigator' : newPoints >= 50 ? 'Silver Commuter' : 'Rookie Rider';

    if (karmaRow) {
      await db.runAsync("UPDATE user_karma SET points = ?, badge = ? WHERE user_id = ?", [newPoints, badge, userId]);
    } else {
      await db.runAsync("INSERT INTO user_karma VALUES (?, ?, ?)", [userId, newPoints, badge]);
    }
    await db.commitTransaction();

    const pingPayload = { routeId, busId, userId, lat, lng, occupancy, timestamp, karmaPoints: newPoints, badge };

    // Real-Time Socket.io Broadcast to all connected clients!
    io.emit('live_ping_update', pingPayload);
    logger.info(`Ping broadcasted via Socket.io for route ${routeId} by ${userId}`);

    res.status(201).json({ message: 'Ping recorded successfully', data: pingPayload });
  } catch (err) {
    await db.rollbackTransaction();
    next(err);
  }
});

// Saved Routes CRUD
app.get('/api/saved-routes', authMiddleware, async (req, res, next) => {
  try {
    const routes = await db.allAsync("SELECT r.* FROM saved_routes sr JOIN routes r ON sr.route_id = r.id WHERE sr.user_id = ?", [req.user.userId]);
    res.json(routes);
  } catch (err) {
    next(err);
  }
});

app.post('/api/saved-routes', authMiddleware, async (req, res, next) => {
  try {
    const { routeId } = req.body;
    await db.runAsync("INSERT OR IGNORE INTO saved_routes (user_id, route_id, saved_at) VALUES (?, ?, ?)", [req.user.userId, routeId, Date.now()]);
    res.status(201).json({ message: 'Route saved successfully.' });
  } catch (err) {
    next(err);
  }
});

// Socket.io Real-Time Connection Event
io.on('connection', (socket) => {
  logger.info(`Client connected to WebSocket: ${socket.id}`);
  socket.on('disconnect', () => logger.info(`Client disconnected: ${socket.id}`));
});

app.use(errorHandler);

const PORT = process.env.PORT || 5000;
if (process.env.NODE_ENV !== 'test') {
  server.listen(PORT, () => {
    logger.info(`StopSync Production Server running on port ${PORT}`);
    logger.info(`Swagger API Docs available at http://localhost:${PORT}/api-docs`);
  });
}

module.exports = { app, server };
