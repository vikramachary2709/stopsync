function validatePingInput(req, res, next) {
  const { routeId, busId, lat, lng, occupancy } = req.body;

  if (!routeId || typeof routeId !== 'string') {
    return res.status(400).json({ error: 'Validation Error', message: 'Valid routeId string is required.' });
  }
  if (!busId || typeof busId !== 'string') {
    return res.status(400).json({ error: 'Validation Error', message: 'Valid busId string is required.' });
  }
  if (typeof lat !== 'number' || lat < -90 || lat > 90) {
    return res.status(400).json({ error: 'Validation Error', message: 'Latitude must be a valid number between -90 and 90.' });
  }
  if (typeof lng !== 'number' || lng < -180 || lng > 180) {
    return res.status(400).json({ error: 'Validation Error', message: 'Longitude must be a valid number between -180 and 180.' });
  }
  const validOccupancy = ['Seats Available', 'Moderate Crowding', 'Full / Crowded'];
  if (occupancy && !validOccupancy.includes(occupancy)) {
    return res.status(400).json({ error: 'Validation Error', message: `Occupancy must be one of: ${validOccupancy.join(', ')}` });
  }

  next();
}

module.exports = { validatePingInput };
