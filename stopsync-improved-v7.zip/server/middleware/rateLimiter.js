const rateLimit = require('express-rate-limit');
const pingLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  message: { error: 'Too Many Requests', message: 'Location ping limit reached (10 pings/min). Please try again later.' }
});
module.exports = { pingLimiter };
