const logger = require('./logger');
function errorHandler(err, req, res, next) {
  logger.error(err.stack || err.message);
  res.status(err.status || 500).json({
    error: err.name || 'InternalServerError',
    message: err.message || 'An unexpected error occurred on the StopSync server.'
  });
}
module.exports = errorHandler;
