const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = process.env.DB_PATH || path.join(__dirname, 'stopsync.db');

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('SQLite connection error:', err.message);
  } else {
    console.log('Connected to SQLite persistent database.');
  }
});

// Helper for promise-based queries
db.runAsync = (sql, params = []) => new Promise((resolve, reject) => {
  db.run(sql, params, function (err) {
    if (err) reject(err);
    else resolve(this);
  });
});

db.allAsync = (sql, params = []) => new Promise((resolve, reject) => {
  db.all(sql, params, (err, rows) => {
    if (err) reject(err);
    else resolve(rows);
  });
});

db.getAsync = (sql, params = []) => new Promise((resolve, reject) => {
  db.get(sql, params, (err, row) => {
    if (err) reject(err);
    else resolve(row);
  });
});

// ACID Transaction Wrapper
db.beginTransaction = () => db.runAsync("BEGIN TRANSACTION;");
db.commitTransaction = () => db.runAsync("COMMIT;");
db.rollbackTransaction = () => db.runAsync("ROLLBACK;");

function initDB() {
  db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS routes (
      id TEXT PRIMARY KEY,
      name TEXT NOT
      corridor TEXT,
      headway_mins INTEGER
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS stops (
      id TEXT PRIMARY KEY,
      route_id TEXT,
      stop_name TEXT,
      sequence INTEGER,
      lat REAL,
      lng REAL,
      FOREIGN KEY(route_id) REFERENCES routes(id)
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS pings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      route_id TEXT,
      bus_id TEXT,
      user_id TEXT,
      lat REAL,
      lng REAL,
      occupancy TEXT,
      timestamp INTEGER
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS saved_routes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT,
      route_id TEXT,
      saved_at INTEGER,
      UNIQUE(user_id, route_id)
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS user_karma (
      user_id TEXT PRIMARY KEY,
      points INTEGER DEFAULT 0,
      badge TEXT DEFAULT 'Rookie Rider'
    )`);

    // Seed Data
    db.get("SELECT COUNT(*) as count FROM routes", (err, row) => {
      if (row && row.count === 0) {
        db.run("INSERT INTO routes VALUES ('R500D', 'Route 500D', 'Outer Ring Road Expressway', 8)");
        db.run("INSERT INTO routes VALUES ('R335E', 'Route 335E', 'IT Corridor & Tech Park', 10)");
        db.run("INSERT INTO routes VALUES ('R201R', 'Route 201R', 'University Express', 15)");

        // Route 500D Stops
        db.run("INSERT INTO stops VALUES ('S101', 'R500D', 'Central Silk Board', 1, 12.9172, 77.6228)");
        db.run("INSERT INTO stops VALUES ('S102', 'R500D', 'HSR Layout Sector 1', 2, 12.9116, 77.6389)");
        db.run("INSERT INTO stops VALUES ('S103', 'R500D', 'Bellandur Tech Park', 3, 12.9260, 77.6762)");
        db.run("INSERT INTO stops VALUES ('S104', 'R500D', 'Kadubeesanahalli', 4, 12.9365, 77.6966)");
        db.run("INSERT INTO stops VALUES ('S105', 'R500D', 'Marathahalli Bridge', 5, 12.9569, 77.7011)");

        // Initial Seed Pings
        const now = Date.now();
        db.run(`INSERT INTO pings (route_id, bus_id, user_id, lat, lng, occupancy, timestamp) 
                VALUES ('R500D', 'BUS-500D-01', 'driver_1', 12.9200, 77.6500, 'Moderate Crowding', ${now - 60000})`);
      }
    });
  });
}

initDB();
module.exports = db;
