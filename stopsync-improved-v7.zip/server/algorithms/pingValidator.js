const { haversineDistance } = require('./etaEngine');

function validatePingProximity(pingLat, pingLng, routeStops, maxDistanceMeters = 200) {
  if (!routeStops || routeStops.length === 0) return true;

  let minDistanceKm = Infinity;

  for (const stop of routeStops) {
    const distKm = haversineDistance(pingLat, pingLng, stop.lat, stop.lng);
    if (distKm < minDistanceKm) {
      minDistanceKm = distKm;
    }
  }

  const minDistanceMeters = minDistanceKm * 1000;
  return {
    isValid: minDistanceMeters <= maxDistanceMeters,
    distanceMeters: Math.round(minDistanceMeters)
  };
}

module.exports = { validatePingProximity };
