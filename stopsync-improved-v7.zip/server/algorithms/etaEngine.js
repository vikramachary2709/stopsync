function haversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Earth radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // distance in km
}

function calculateETA(stopLat, stopLng, busLat, busLng, pingTimestamp, averageSpeedKmh = 25) {
  const distanceKm = haversineDistance(stopLat, stopLng, busLat, busLng);
  const timeHours = distanceKm / averageSpeedKmh;
  let estimatedMins = Math.round(timeHours * 60);

  // Recency Decay Penalty W = e^(-lambda * t)
  const pingAgeSeconds = (Date.now() - pingTimestamp) / 1000;
  const lambda = 0.003; // decay coefficient
  const confidence = Math.exp(-lambda * pingAgeSeconds);

  // Apply decay penalty: older pings increase uncertainty margin
  if (confidence < 0.7) {
    estimatedMins += Math.round((1 - confidence) * 5);
  }

  return {
    etaMinutes: Math.max(1, estimatedMins),
    distanceKm: parseFloat(distanceKm.toFixed(2)),
    confidenceScore: parseFloat(confidence.toFixed(2)),
    isLive: confidence > 0.4
  };
}

module.exports = { haversineDistance, calculateETA };
