const { validatePingProximity } = require('../server/algorithms/pingValidator');

describe('Polyline 200m Corridor Validator', () => {
  const routeStops = [
    { lat: 12.9172, lng: 77.6228 },
    { lat: 12.9116, lng: 77.6389 }
  ];

  test('accepts pings within 200 meters of route polyline', () => {
    const result = validatePingProximity(12.9173, 77.6229, routeStops, 200);
    expect(result.isValid).toBe(true);
    expect(result.distanceMeters).toBeLessThanOrEqual(200);
  });

  test('rejects pings further than 200 meters from route polyline', () => {
    const result = validatePingProximity(12.9900, 77.7000, routeStops, 200);
    expect(result.isValid).toBe(false);
    expect(result.distanceMeters).toBeGreaterThan(200);
  });
});
