const request = require('supertest');
const { app } = require('../server/index');

describe('Strict JWT Security Enforcement', () => {
  test('rejects unauthenticated ping submissions with 401 Unauthorized', async () => {
    const response = await request(app)
      .post('/api/pings')
      .send({ routeId: 'R500D', busId: 'BUS-01', lat: 12.9172, lng: 77.6228 });

    expect(response.status).toBe(401);
    expect(response.body.error).toBe('Unauthorized');
  });

  test('accepts ping submissions with valid JWT Bearer token', async () => {
    // 1. Get Token
    const loginRes = await request(app).post('/api/auth/login').send({ username: 'test_commuter' });
    const token = loginRes.body.token;

    // 2. Submit Ping
    const response = await request(app)
      .post('/api/pings')
      .set('Authorization', `Bearer ${token}`)
      .send({ routeId: 'R500D', busId: 'BUS-01', lat: 12.9172, lng: 77.6228, occupancy: 'Moderate Crowding' });

    expect(response.status).toBe(201);
    expect(response.body.data.userId).toBe('test_commuter');
  });
});
