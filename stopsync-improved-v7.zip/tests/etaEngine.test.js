const { haversineDistance, calculateETA } = require('../server/algorithms/etaEngine');

describe('ETA Heuristic Engine', () => {
  test('haversineDistance calculates accurate spatial distances in km', () => {
    // Silk Board to HSR Layout (~1.8km)
    const dist = haversineDistance(12.9172, 77.6228, 12.9116, 77.6389);
    expect(dist).toBeGreaterThan(1.0);
    expect(dist).toBeLessThan(3.0);
  });

  test('calculateETA applies recency decay penalty W = e^(-lambda * t) for old pings', () => {
    const recentPingTime = Date.now() - 30000; // 30s ago
    const oldPingTime = Date.now() - 600000;  // 10 mins ago

    const recentETA = calculateETA(12.9172, 77.6228, 12.9116, 77.6389, recentPingTime);
    const oldETA = calculateETA(12.9172, 77.6228, 12.9116, 77.6389, oldPingTime);

    expect(recentETA.isLive).toBe(true);
    expect(oldETA.isLive).toBe(false);
    expect(recentETA.confidenceScore).toBeGreaterThan(oldETA.confidenceScore);
  });
});
