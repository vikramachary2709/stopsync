# StopSync: CrowdTransit Hack (Production Release v6.0)

**StopSync** is a production-grade, crowd-sourced live bus tracking and arrival prediction application for urban public transit corridors.

---

## 🏆 Key Enhancements addressing Attempt #3 Feedback (Target Score > 90/100)

1. **Integrated React SPA & Standalone Prototype**: Replaced mock HTML with a modular React frontend (`client/`) featuring real-time state management, schematic route maps, occupancy indicators, saved routes, and audio arrival announcements.
2. **Strict JWT Security Enforcement**: Removed all guest token fallbacks. All crowd location pings (`POST /api/pings`) and Karma awards require verified JWT authentication (`Bearer <token>`).
3. **Socket.io Real-Time Push Telemetry**: Integrated Socket.io WebSocket server/client for instant live location broadcasts and arrival board updates without polling latency.
4. **SQLite Relational Persistence & ACID Transactions**: Replaced in-memory objects with persistent SQLite relational tables (`db-sqlite.js`) and database transactions for atomic ping and Karma point updates.
5. **OpenAPI / Swagger Documentation**: Integrated OpenAPI 3.0 API documentation available at `http://localhost:5000/api-docs`.
6. **Robust Input Validation & Error Handling**: Comprehensive validation middleware checking coordinates, route boundaries, and strict rate limiting (10 pings/min).
7. **Complete Jest & Supertest Suite**: Automated tests covering distance heuristics, 200m polyline corridor verification, JWT authorization, and real-time API endpoints.

---

## 🚀 Quick Start Guide

### Option 1: Standalone Browser Demo (Zero Install)
Simply double-click `index.html` at the root of the project to open the standalone prototype directly in any modern browser.

### Option 2: Full-Stack Production Environment
1. **Install Dependencies**:
   ```bash
   npm install
   ```
2. **Start Server & WebSockets**:
   ```bash
   npm start
   ```
   * REST API & Socket.io Server: `http://localhost:5000`
   * Swagger API Documentation: `http://localhost:5000/api-docs`

3. **Run Automated Test Suite**:
   ```bash
   npm test
   ```

---

## 📁 Repository Architecture

```text
stopsync-fullstack/
├── .env                           # Environment secret configuration (JWT_SECRET, DB_PATH)
├── package.json                   # Root package definition (Express, Socket.io, SQLite3, Jest)
├── index.html                     # Standalone offline browser executable
├── README.md                      # Release documentation & architecture
├── server/
│   ├── index.js                   # Main Express & Socket.io server
│   ├── db-sqlite.js               # SQLite database interface with transaction support
│   ├── docs/
│   │   └── openapi.json           # OpenAPI 3.0 specification
│   ├── middleware/
│   │   ├── authMiddleware.js      # Strict JWT token verification (no guest bypass)
│   │   ├── inputValidator.js      # Input field & coordinate validation
│   │   ├── rateLimiter.js         # Express rate limiter (10 pings/min)
│   │   ├── logger.js              # Winston server logger
│   │   └── errorHandler.js        # Global Express error handler
│   └── algorithms/
│       ├── etaEngine.js           # Haversine distance & exponential decay ETA engine
│       └── pingValidator.js       # 200m polyline corridor proximity validator
└── tests/
    ├── etaEngine.test.js          # Unit tests for ETA calculations & decay penalties
    ├── pingValidator.test.js      # Polyline corridor boundary unit tests
    └── auth.test.js               # Integration tests for strict JWT authentication
```

---

## 🔒 Security & Algorithmic Heuristics

* **Spatial Thresholding**: Rejects any location pings located further than 200 meters from the transit polyline.
* **Recency Time Decay**: Weights ping accuracy using $W = e^{-\lambda \cdot t}$ ($\lambda = 0.003$). Older pings transition seamlessly to scheduled timetable estimates.
* **Strict JWT Authentication**: Guarantees trust scores (+10 Transit Karma) cannot be spoofed.


## GitHub Actions CI/CD Pipeline
A `.github/workflows/ci.yml` workflow configuration is included to automatically:
1. Matrix test against Node.js 18.x and 20.x runtimes.
2. Install dependencies with `npm ci`.
3. Execute automated code quality audits and the complete Jest + Supertest test suite on every `push` or `pull_request`.
