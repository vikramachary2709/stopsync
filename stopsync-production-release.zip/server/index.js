const express = require('express');
const cors = require('cors');
const { initDB, seedRoutes, seedStops } = require('./db');
const { computeETA } = require('./algorithms/etaEngine');
const { validatePingCorridor } = require('./algorithms/pingValidator');
const busSimulator = require('./simulation/busSimulator');

const app = express();
app.use(cors());
app.use(express.json());

initDB();
setInterval(() => busSimulator.step(), 4000);

app.get('/api/routes', (req, res) => res.json(seedRoutes));
app.get('/api/stops', (req, res) => res.json(seedStops));
app.get('/api/buses', (req, res) => res.json(busSimulator.buses));

app.get('/api/eta', (req, res) => {
    const { busId, stopId } = req.query;
    const bus = busSimulator.buses.find(b => b.id === busId) || busSimulator.buses[0];
    const stop = seedStops.find(s => s.id === stopId) || seedStops[2];
    res.json(computeETA(bus.lat, bus.lng, stop.lat, stop.lng, bus.speed, bus.lastUpdated));
});

app.post('/api/pings', (req, res) => {
    const { userId, busId, routeId, lat, lng, occupancy } = req.body;
    const validation = validatePingCorridor(lat, lng, seedStops, 200);

    if (!validation.isValid) {
        return res.status(400).json({ error: validation.reason });
    }

    res.json({
        status: 'SUCCESS',
        message: 'Location ping validated. +10 Transit Karma awarded!',
        karmaEarned: 10
    });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`StopSync Server listening on port ${PORT}`));
