const { seedStops } = require('../db');

class BusSimulator {
    constructor() {
        this.buses = [
            { id: 'BUS-500D-01', routeId: '500D', stopIndex: 0, lat: seedStops[0].lat, lng: seedStops[0].lng, occupancy: 'Seats Available', speed: 24.0 },
            { id: 'BUS-335E-02', routeId: '335E', stopIndex: 1, lat: seedStops[1].lat, lng: seedStops[1].lng, occupancy: 'Standing Only', speed: 18.5 }
        ];
    }

    step() {
        this.buses.forEach(bus => {
            const nextIndex = (bus.stopIndex + 1) % seedStops.length;
            const targetStop = seedStops[nextIndex];
            bus.lat += (targetStop.lat - bus.lat) * 0.15;
            bus.lng += (targetStop.lng - bus.lng) * 0.15;

            if (Math.abs(bus.lat - targetStop.lat) < 0.001 && Math.abs(bus.lng - targetStop.lng) < 0.001) {
                bus.stopIndex = nextIndex;
            }
            bus.lastUpdated = Date.now();
        });
        return this.buses;
    }
}

module.exports = new BusSimulator();
