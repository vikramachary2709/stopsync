const { calculateDistanceKm } = require('./etaEngine');

function validatePingCorridor(pingLat, pingLng, routeStops, maxDistanceMeters = 200) {
    let minDistanceM = Infinity;
    routeStops.forEach(stop => {
        const distKm = calculateDistanceKm(pingLat, pingLng, stop.lat, stop.lng);
        const distM = distKm * 1000;
        if (distM < minDistanceM) minDistanceM = distM;
    });

    const isValid = minDistanceM <= maxDistanceMeters;
    return {
        isValid: isValid,
        distanceToCorridorMeters: Math.round(minDistanceM),
        reason: isValid ? 'Valid ping' : `Exceeds 200m corridor distance (${Math.round(minDistanceM)}m)`
    };
}

module.exports = { validatePingCorridor };
