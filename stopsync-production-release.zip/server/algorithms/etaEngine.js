function calculateDistanceKm(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
}

function computeETA(busLat, busLng, stopLat, stopLng, averageSpeedKmh = 22.5, lastPingTimeMs = null) {
    const distKm = calculateDistanceKm(busLat, busLng, stopLat, stopLng);
    let travelTimeMins = Math.round((distKm / averageSpeedKmh) * 60);
    
    let etaType = 'Scheduled';
    if (lastPingTimeMs && (Date.now() - lastPingTimeMs) < 10 * 60 * 1000) {
        etaType = 'Live Crowd Ping';
    }
    
    return {
        etaMinutes: Math.max(1, travelTimeMins),
        distanceKm: parseFloat(distKm.toFixed(2)),
        etaType: etaType
    };
}

module.exports = { calculateDistanceKm, computeETA };
