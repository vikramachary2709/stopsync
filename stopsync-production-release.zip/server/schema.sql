CREATE TABLE IF NOT EXISTS routes (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    corridor TEXT NOT NULL,
    operating_hours TEXT NOT NULL,
    headway_mins INTEGER NOT NULL,
    color TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stops (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    lat REAL NOT NULL,
    lng REAL NOT NULL,
    landmark TEXT
);

CREATE TABLE IF NOT EXISTS active_buses (
    bus_id TEXT PRIMARY KEY,
    route_id TEXT NOT NULL,
    lat REAL NOT NULL,
    lng REAL NOT NULL,
    speed_kmh REAL DEFAULT 22.5,
    occupancy TEXT DEFAULT 'Seats Available',
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS crowd_pings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bus_id TEXT NOT NULL,
    route_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    lat REAL NOT NULL,
    lng REAL NOT NULL,
    occupancy TEXT NOT NULL,
    distance_to_corridor_m REAL NOT NULL,
    is_valid INTEGER DEFAULT 1,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_karma (
    user_id TEXT PRIMARY KEY,
    karma_points INTEGER DEFAULT 0,
    valid_pings_count INTEGER DEFAULT 0,
    badge_title TEXT DEFAULT 'Rookie Rider'
);
