const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const dbPath = path.join(__dirname, 'stopsync.db');
const db = new sqlite3.Database(dbPath);

const seedRoutes = [
    { id: '500D', name: 'Route 500D', corridor: 'Outer Ring Road Express', operating_hours: '05:30 - 23:00', headway_mins: 10, color: '#2563eb' },
    { id: '335E', name: 'Route 335E', corridor: 'IT Corridor Direct', operating_hours: '06:00 - 22:30', headway_mins: 12, color: '#10b981' },
    { id: '201R', name: 'Route 201R', corridor: 'University & Metro Feeder', operating_hours: '06:15 - 21:45', headway_mins: 15, color: '#f59e0b' }
];

const seedStops = [
    { id: 's1', name: 'Central Terminal', lat: 12.9716, lng: 77.5946, landmark: 'Platform 1' },
    { id: 's2', name: 'City Circle', lat: 12.9810, lng: 77.6010, landmark: 'Metro Gate B' },
    { id: 's3', name: 'Tech Park Gate', lat: 12.9925, lng: 77.6150, landmark: 'Tech Flyover' },
    { id: 's4', name: 'Innovation Hub', lat: 13.0040, lng: 77.6290, landmark: 'Main Entrance' },
    { id: 's5', name: 'Metro Interchange', lat: 13.0150, lng: 77.6410, landmark: 'Skywalk Link' }
];

function initDB() {
    db.serialize(() => {
        const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
        db.exec(schema, (err) => {
            if (err) console.error("Database schema initialization error:", err);
            else console.log("SQLite schema initialized successfully.");
        });
    });
}

module.exports = { db, initDB, seedRoutes, seedStops };
